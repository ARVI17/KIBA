# backend/app/routes/paciente.py

from flask import Blueprint, request, jsonify
from backend.app.config import db
from models.paciente import Paciente
from models.sms import Especialidad
from utils.token_manager import token_requerido
from datetime import datetime

paciente_bp = Blueprint('paciente', __name__)

@paciente_bp.route('/pacientes', methods=['POST'])
@token_requerido
def crear_paciente():
    datos = request.get_json()

    nombre = datos.get('nombre')
    celular = datos.get('celular')
    especialidad_id = datos.get('especialidad_id')
    programada = datos.get('programada')  # Opcional

    if not nombre or not celular or not especialidad_id:
        return jsonify({'error': 'Faltan datos obligatorios.'}), 400

    if Paciente.query.filter_by(celular=celular).first():
        return jsonify({'error': 'Ya existe un paciente con este celular.'}), 400

    nuevo_paciente = Paciente(
        nombre=nombre,
        celular=celular,
        especialidad_id=especialidad_id,
        programada=datetime.strptime(programada, '%Y-%m-%d %H:%M:%S') if programada else None
    )

    db.session.add(nuevo_paciente)
    db.session.commit()

    return jsonify({'mensaje': 'Paciente creado exitosamente.'}), 201

@paciente_bp.route('/pacientes', methods=['GET'])
@token_requerido
def listar_pacientes():
    pacientes = Paciente.query.all()
    return jsonify([paciente.to_dict() for paciente in pacientes]), 200
